const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constant = require('./constant')();
const table = constant.TABLES;



const userSettingsSchema = new Schema({
    isEnableDriverCallOption:{type: Boolean, default: true},
    isIdleLogEnable: {type: Boolean, default: false},
    isImageOption: {type: Boolean, default: false},
    isSuccessEditOption: {type: Boolean, default: false},
    clientId: {type: String},
    isSupportEmail: {type: Boolean, default: false},
    isDriverPinCode: {type: Boolean, default: false},
    isTaskPinCode: {type: Boolean, default: false},
    isTeamPinCode: {type: Boolean, default: false},
    isDashboardMapEnable: {type: Boolean, default: true},
    isDriverCreateOwnTask: {type: Boolean, default: false},
    isEarningsModule: {type: Boolean, default: false},
    isPODImageCompress: {type: Boolean, default: true},
    isOTPVerificationEnable: {type: Boolean, default: false},
    isTaskImportUpdate: {type: Boolean, default: false},
    addMultipleCustomer: {type: Boolean, default: false},
    isGlympseEnable :{type:Boolean, default: false},
    isDisableRatingRedirect: {type:Boolean, default: false},
    isNewUser: {type:Boolean, default: false},
    glympseConfig :{type:Schema.Types.Mixed, default:{
            accessToken:'',
            userName:'',
            password:'',
            orgId:'',
            orgName:'',
            glympseKey:''
        }
    }
});


const userSettingsModel = mongoose.model(table.USERSETTINGS, userSettingsSchema);

module.exports = {userSettings: userSettingsModel};
